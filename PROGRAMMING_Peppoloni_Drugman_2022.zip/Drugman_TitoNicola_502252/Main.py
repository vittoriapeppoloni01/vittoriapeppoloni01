"""

Castle War
Version: 5.0

Designed and created by: Vittoria Peppoloni and Tito Nicola Drugman

"""


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# **** IMPORT

import pygame
from SaveLoadManager import SaveLoadSystem
from pygame import mixer

import os
import random as rd
import json
import sys
import pickle

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# **** BASIC INFORMATION
pygame.init()
FPS = 60  # frames per second
clock = pygame.time.Clock()

#background sound
mixer.music.load('dance-of-nordic-leaves-epic-folk-original-soundtrack.mp3')
mixer.music.stop()

# Screen information
WIDTH = 1200            # Width of the display (in pixel)
HEIGHT = 600            # height of the display (in pixel)
SIZE = WIDTH, HEIGHT
DISPLAYSURF = pygame.display.set_mode(SIZE)
background_image = pygame.image.load("ExtraAnimation/Decoration/Nightbackground.png")       # check .txt file for copyright

# Color used
RED = (255, 0, 0)
BLUE = (0, 0, 255)
LIGHTBLUE = (165, 217, 250)             # used for the sky
GRAY = (157, 157, 157)                  # used for the settings tab
PURPLE = (38, 9, 54)                    # used for the "grass"
BLACK = (0, 0, 0)                       # used for text

RECT_COLOR = pygame.Color(PURPLE)       # the ground color (purple)

# Icon and window name
pygame.display.set_caption("CASTLES WAR")       # display the name on the opened window
programIcon = pygame.image.load('icon.png')     # load the logo of the opened window
pygame.display.set_icon(programIcon)            # display the logo on the opened window

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** CONSTANTS

# set game values
INIT_RESOURCES = INIT_RESOURCES1 = INIT_RESOURCES2 = 100  # initial amount of resources

# ******** Building constants
# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Tower
TOWER_HEALTH = 1000     # maximum amount of HP of the tower
TOWER_RANGE_1 = 500     # maximum distance (1) at which the tower can send an arrow
TOWER_RANGE_2 = 400     # maximum distance (2) at which the tower can send an arrow
TOWER_HIT = 11          # damage caused by of an arrow shoot by the tower
TOWER_POS = 225         # horizontal coordinate of the right of the tower
TOWER_WIDTH = 62        # tower width
TOWER_HEIGHT = 240      # tower height

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Mine
MINE_POS = 0            # horizontal coordinate of the left of the mine
MINE_WIDTH = 58         # mine width
MINE_HEIGHT = 37        # mine width

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Barracks
BARRACKS_POS = 80       # horizontal coordinate of the left of the barracks
BARRACK_WIDTH = 62      # barrack width
BARRACK_HEIGHT = 50     # barrack height

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Ground
GROUND_HEIGHT = 550     # height of the ground
bottom_rect = pygame.Rect(0, 550, 1200, HEIGHT - 550)

# ******** Units constants
# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# ********** Swordman
SWORDMAN_POS = 165      # initial left position of a swordman
SWORDMAN_COST = 5       # amount of resources to train a new swordman
SWORDMAN_TRAIN = 20     # amount of turns to train a new swordman
SWORDMAN_RANGE = 10     # maximum distance at which a swordman can hit an unit
SWORDMAN_SPEED = 1      # distance covered in one turn by a running swordman
SWORDMAN_HIT = 2        # damage caused by of a swordman per turn
SWORDMAN_HEALTH = 24    # initial amount of HP of a swordman
SWORDMAN_WIDTH = 16     # width of the ready.png
SWORDMAN_HEIGHT = 20    # height of the ready.png

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Worker
WORKER_POS = 115
WORKER_COST = 2         # amount of resources to train a new worker
WORKER_TRAIN = 20       # amount of turns to train a new worker
WORKER_SPEED = 1        # distance covered in one turn by a running worker
WORKER_PROD = 3         # amount of resources per turn mined by a worker in mine
WORKER_REPAIR = 2       # amount of HP restored per turn by a worker in tower
WORKER_WIDTH = 16       # width of the ready.png
WORKER_HEIGHT = 20      # height of the ready.png

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Bowman
BOWMAN_POS = 215        # initial left position of a bowman
BOWMAN_COST = 7         # amount of resources to train a new bowman
BOWMAN_TRAIN = 40       # amount of turns to train a new bowman
BOWMAN_SPEED = 2        # distance covered in one turn by a running bowman
BOWMAN_REST = 40        # amount of turns of inactivity of a bowman after shooting
BOWMAN_HIT = 8          # damage caused by of an arrow shoot by a bowman
BOWMAN_HEALTH = 30      # initial amount of HP of a bowman
BOWMAN_WIDTH = 17       # width of the ready.png
BOWMAN_HEIGHT = 23      # height of the ready.png

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Arrow
ARROW_VEL = 5           # distance covered in one turn by an arrow

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# Keyboard commands
WORKER1_TRAIN = 'q'
SWORDMAN1_TRAIN = 'w'
ARCHER1_TRAIN = 'e'
PL1_TO_MINE = 'a'
PL1_TO_WALL = 's'
SWORDMAN1_ATTACK = 'd'
ARCHER1 = 'f'
UNLEASH1 = 'z'

WORKER2_TRAIN = 'p'
SWORDMAN2_TRAIN = 'o'
ARCHER2_TRAIN = 'i'
PL2_TO_MINE = 'l'
PL2_TO_WALL = 'k'
SWORDMAN2_ATTACK = 'j'
ARCHER2 = 'h'
UNLEASH2 = 'm'

PAUSE = ' '
SAVE = 'V'
LOAD = 'B'

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# font used
font_number1 = pygame.font.SysFont('Sans Serif', 27)
font_number2 = pygame.font.SysFont('Sans Serif', 20)
font_number3 = pygame.font.SysFont('Sans Serif', 24)

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** SPRITES LOAD

# ********** Barracks 1 (red)
Redbarrack = pygame.transform.scale(pygame.image.load('sprites/player1/building/barracks.png'), (BARRACK_WIDTH, BARRACK_HEIGHT))

# ********** Barrack 2 (blue)
Bluebarrack = pygame.transform.scale(pygame.image.load('sprites/player2/building/barracks.png'), (BARRACK_WIDTH, BARRACK_HEIGHT))

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** CLASSES

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# CLASS 1: SWORDMAN

#  ********** Swordman 1 (red)
ready_1_swordman = pygame.image.load(os.path.join('sprites', 'player1', 'sword', 'ready.png'))

run_1_swordman = []
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-1.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-2.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-3.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-4.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-5.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-6.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-7.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-8.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-9.png'))
run_1_swordman.append(pygame.image.load('sprites/player1/sword/run-10.png'))

attack_1_swordman = []
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-0.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-1.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-2.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-3.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-4.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-5.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-6.png'))
attack_1_swordman.append(pygame.image.load('sprites/player1/sword/attack-7.png'))

fallen_1_swordman = []
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-0.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-1.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-2.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-3.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-4.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-5.png'))
fallen_1_swordman.append(pygame.image.load('sprites/player1/sword/fallen-5.png'))


class Swordman_1(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_attack, sprites_fallen):

        super().__init__()

        self.unleash = False            # free all the swordman (false by default)
        self.is_attack_units = False    # a swordman attack a swordman (false by default)
        self.is_attack_tower = False    # a swordman attack a tower (false by default)
        self.is_fallen = False          # a swordman is fallen (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.attack = sprites_attack
        self.is_fallen = sprites_fallen
        self.image = self.ready
        self.tic = 0
        self.index = 0                  # used for chaining the image
        self.time = 0
        self.health = SWORDMAN_HEALTH

        self.rect = self.image.get_rect(left=BARRACKS_POS + (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1
        if self.time > SWORDMAN_TRAIN and self.unleash == True and self.is_attack_units == False and self.is_attack_tower == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x += SWORDMAN_SPEED

        # if a swordman is attacking a unit or the tower display the correct sprites
        if self.is_attack_units == True or self.is_attack_tower == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.attack):
                self.index = 0

            self.image = self.attack[self.index]

        # check if a unit is dead
        if self.health <= 0:
            self.rect.x -= SWORDMAN_SPEED
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.is_fallen):
                self.index = 0
                self.kill()
                if self.kill:
                    # used for the counter
                    global total_swordman_death_1
                    total_swordman_death_1 += 1
            self.image = self.is_fallen[self.index]


#  ********** Swordman 2 (blue)
ready_2_swordman = pygame.image.load(os.path.join('sprites', 'player2', 'sword', 'ready.png'))

run_2_swordman = []
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-1.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-2.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-3.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-4.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-5.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-6.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-7.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-8.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-9.png'))
run_2_swordman.append(pygame.image.load('sprites/player2/sword/run-10.png'))

attack_2_swordman = []
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-0.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-1.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-2.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-3.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-4.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-5.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-6.png'))
attack_2_swordman.append(pygame.image.load('sprites/player2/sword/attack-7.png'))

fallen_2_swordman = []
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-0.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-1.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-2.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-3.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-4.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-5.png'))
fallen_2_swordman.append(pygame.image.load('sprites/player2/sword/fallen-5.png'))


class Swordman_2(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_attack, sprites_fallen):

        super().__init__()

        self.unleash = False            # free all the swordman (false by default)
        self.is_attack_units = False    # a swordman attack a swordman (false by default)
        self.is_attack_tower = False    # a swordman attack a tower (false by default)
        self.is_fallen = False          # a swordman is fallen (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.attack = sprites_attack
        self.image = self.ready
        self.is_fallen = sprites_fallen
        self.tic = 0
        self.index = 0                  # used for chaining the image
        self.time = 0
        self.health = SWORDMAN_HEALTH
        self.rect = self.image.get_rect(right=WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1
        if self.time > SWORDMAN_TRAIN and self.unleash == True and self.is_attack_units == False and self.is_attack_tower == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x -= SWORDMAN_SPEED

        # if a swordman is attacking a unit or the tower display the correct sprites
        if self.is_attack_units == True or self.is_attack_tower == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.attack):
                self.index = 0

            self.image = self.attack[self.index]

        # if a swordman is dead
        if self.health <= 0:
            self.rect.x += SWORDMAN_SPEED
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.is_fallen):
                self.index = 0
                self.kill()
                if self.kill:
                    # used for the counter
                    global total_swordman_death_2
                    total_swordman_death_2 += 1

            self.image = self.is_fallen[self.index]


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# CLASS 2: WORKER

#  ********** Worker 1 (red)
worker_1_ready = pygame.transform.flip((pygame.image.load(os.path.join('sprites', 'player1', 'worker', 'ready.png'))), True, False)

# flip the image because it is going in the opposite direction to the mine
run_1_workers_mine = []
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-1.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-2.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-3.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-4.png'), True, False))
run_1_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/run-5.png'), True, False))

run_1_workers_tower = []
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-1.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-2.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-3.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-4.png'))
run_1_workers_tower.append(pygame.image.load('sprites/player1/worker/run-5.png'))

mine_1_worker = []
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-0.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-1.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-2.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-3.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-4.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-5.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-6.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-7.png'), True, False))
mine_1_worker.append(pygame.transform.flip(pygame.image.load('sprites/player1/worker/dig-8.png'), True, False))

repair_1_worker = []
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-0.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-1.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-2.png'))
repair_1_worker.append(pygame.image.load('sprites/player1/worker/repair-3.png'))


class Worker_1(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair):

        super().__init__()

        self.gotominer = False          # specify if the worker is going to the mine (false by default)
        self.gototower = False          # specify if the worker is going to the tower (false by default)
        self.is_at_mine = False         # specify if the worker is in front of the mine (false by default)
        self.is_at_wall = False         # specify if the worker is in front of the wall (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run_mine = sprites_run_mine
        self.run_tower = sprites_run_tower
        self.mine = sprites_mine
        self.repair = sprites_repair
        self.image = self.ready
        self.tic = 0
        self.index = 0                  # used for chaining the image
        self.time = 0

        self.rect = self.image.get_rect(left=BARRACKS_POS + (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # CASE 1: the worker goes to the mine
        if self.time > WORKER_TRAIN and self.is_at_mine == False and self.gotominer == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_mine):
                self.index = 0

            self.rect.x -= WORKER_SPEED         # use the speed negative because it needs to go "backwords"
            self.image = self.run_mine[self.index]

        # CASE 2: the worker goes to the wall
        if self.time > 100 and self.is_at_mine == False and self.gototower == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_tower):
                self.index = 0

            self.rect.x += WORKER_SPEED         # use the speed positive
            self.image = self.run_tower[self.index]

        # CASE 1: connect with the mine sprites
        if self.is_at_mine == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.mine):
                self.index = 0

            self.image = self.mine[self.index]

        # CASE 2: connect with the wall sprites
        if self.is_at_wall == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.repair):
                self.index = 0

            self.image = self.repair[self.index]


#  ********** Worker 2 (blue)
ready_2_worker = pygame.transform.flip((pygame.image.load(os.path.join('sprites', 'player2', 'worker', 'ready.png'))), True, False)

# flip the image because it is going in the opposite direction to the mine
run_2_workers_mine = []
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-1.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-2.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-3.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-4.png'), True, False))
run_2_workers_mine.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/run-5.png'), True, False))

run_2_workers_tower = []
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-1.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-2.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-3.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-4.png'))
run_2_workers_tower.append(pygame.image.load('sprites/player2/worker/run-5.png'))

mine_2_worker = []
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-0.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-1.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-2.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-3.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-4.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-5.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-6.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-7.png'), True, False))
mine_2_worker.append(pygame.transform.flip(pygame.image.load('sprites/player2/worker/dig-8.png'), True, False))

repair_2_worker = []
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-0.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-1.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-2.png'))
repair_2_worker.append(pygame.image.load('sprites/player2/worker/repair-3.png'))

class Worker_2(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run_mine, sprites_run_tower, sprites_mine, sprites_repair):

        super().__init__()

        self.gotominer = False          # specify if the worker is going to the mine (false by default)
        self.gototower = False          # specify if the worker is going to the tower (false by default)
        self.is_at_mine = False         # specify if the worker is in front of the mine (false by default)
        self.is_at_wall = False         # specify if the worker is in front of the wall (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run_mine = sprites_run_mine
        self.run_tower = sprites_run_tower
        self.mine = sprites_mine
        self.repair = sprites_repair
        self.image = self.ready
        self.tic = 0
        self.index = 0                  # used for chaining the image
        self.time = 0

        self.rect = self.image.get_rect(right=WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # CASE 1: the worker goes to the mine
        if self.time > WORKER_TRAIN and self.is_at_mine == False and self.gotominer == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_mine):
                self.index = 0

            self.rect.x += WORKER_SPEED         # use the speed positive
            self.image = self.run_mine[self.index]

        # CASE 2: the worker goes to the wall
        if self.time > 100 and self.is_at_mine == False and self.gototower == True and self.is_at_wall == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run_tower):
                self.index = 0

            self.rect.x -= WORKER_SPEED         # use the speed negative because it needs to go "backwords"
            self.image = self.run_tower[self.index]

        # CASE 1: connect with the mine sprites
        if self.is_at_mine == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.mine):
                self.index = 0

            self.image = self.mine[self.index]

        # CASE 2: connect with the wall sprites
        if self.is_at_wall == True:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.repair):
                self.index = 0

            self.image = self.repair[self.index]


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# CLASS 3: BOWMAN

#  ********** Bowman 1 (red)
ready_1_bowman = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'ready.png'))
arrow_1 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowhor-0.png'))

run_1_bowman = []
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-1.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-2.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-3.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-4.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-5.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-6.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-7.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-8.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-9.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-10.png'))
run_1_bowman.append(pygame.image.load('sprites/player1/bow/run-11.png'))

shoot_1_bowman = []
shoot_1_bowman.append(pygame.image.load('sprites/player1/bow/shoot-0.png'))
shoot_1_bowman.append(pygame.image.load('sprites/player1/bow/shoot-1.png'))

fallen_1_bowman = []
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-0.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-1.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-2.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-3.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-4.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-5.png'))
fallen_1_bowman.append(pygame.image.load('sprites/player1/bow/fallen-5.png'))


class Bowman_1(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_shoot, sprites_fallen):

        super().__init__()

        self.isshoot = False            # check if the bowman is shooting (false by default)
        self.unleash = False            # unleash bowman (false by default)
        self.is_fallen = False          # a swordman is fallen (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.shoot = sprites_shoot
        self.is_fallen = sprites_fallen
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0
        self.health = BOWMAN_HEALTH

        self.rect = self.image.get_rect(left=BARRACKS_POS + (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # CASE 1: unleashed bowman
        if self.time > BOWMAN_TRAIN and self.unleash == True and self.isshoot == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x += BOWMAN_SPEED

        # CASE 2: shooting bowman
        if self.isshoot == True:
            self.tic += 1
            if self.tic == BOWMAN_REST:
                self.index = 1
            if self.tic == 230:
                self.index = 0
                self.tic = 0
            if self.index >= len(self.shoot):
                self.index = 0

            self.image = self.shoot[self.index]

        # CASE 3: bowman die
        if self.health <= 0:
            self.kill()
            if self.kill:
                global total_bowman_death_1
                total_bowman_death_1 += 1


#  ********** Bowman 2 (blue)
ready_2_bowman = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'ready.png'))
arrow_2 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowhor-0.png'))

run_2_bowman = []
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-1.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-2.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-3.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-4.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-5.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-6.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-7.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-8.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-9.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-10.png'))
run_2_bowman.append(pygame.image.load('sprites/player2/bow/run-11.png'))

shoot_2_bowman = []
shoot_2_bowman.append(pygame.image.load('sprites/player2/bow/shoot-0.png'))
shoot_2_bowman.append(pygame.image.load('sprites/player2/bow/shoot-1.png'))


class Bowman_2(pygame.sprite.Sprite):
    def __init__(self, sprites_ready, sprites_run, sprites_shoot):

        super().__init__()

        self.isshoot = False            # check if the bowman is shooting (false by default)
        self.unleash = False            # unleash bowman (false by default)

        # connect with the sprites
        self.ready = sprites_ready
        self.run = sprites_run
        self.shoot = sprites_shoot
        self.image = self.ready
        self.tic = 0
        self.index = 0
        self.time = 0
        self.health = BOWMAN_HEALTH

        self.rect = self.image.get_rect(right=WIDTH - BARRACKS_POS - (BARRACK_WIDTH / 2), bottom=GROUND_HEIGHT)

    def update(self):
        self.time += 1

        # CASE 1: unleashed bowman
        if self.time > BOWMAN_TRAIN and self.unleash == True and self.isshoot == False:
            self.tic += 1
            if self.tic == 6:
                self.index += 1
                self.tic = 0
            if self.index >= len(self.run):
                self.index = 0

            self.image = self.run[self.index]

            self.rect.x -= BOWMAN_SPEED

        # CASE 2: shooting bowman
        if self.isshoot == True:
            self.tic += 1
            if self.tic == BOWMAN_REST:
                self.index = 1
            if self.tic == 230:
                self.index = 0
                self.tic = 0
            if self.index >= len(self.shoot):
                self.index = 0

            self.image = self.shoot[self.index]

        # CASE 3: bowman die
        if self.health <= 0:
            self.kill()
            if self.kill:
                global total_bowman_death_2
                total_bowman_death_2 += 1


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
#  ********** Arrow 1 (red)
tower_1_arrows_pos_1 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowdiag-0.png'))
tower_1_arrows_pos_2 = pygame.image.load(os.path.join('sprites', 'player1', 'bow', 'arrowdiag-0.png'))

class Arrow_1(pygame.sprite.Sprite):
    def __init__(self, arrow_1):
        super().__init__()

        self.image = arrow_1
        self.rect = self.image.get_rect(left= 685, top=GROUND_HEIGHT - (BOWMAN_HEIGHT/2) - 3)          # 685: average between the position in which the bowman can start shooting. 3: extra height of the arrow from the ground

    def update(self):
        self.rect.x += ARROW_VEL


class Tower_1_arrows_pos_1(pygame.sprite.Sprite):
    def __init__(self, tower_1_arrows_pos_1):
        super().__init__()

        self.image = tower_1_arrows_pos_1
        self.rect = self.image.get_rect(left=TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x += 6
        self.rect.y += 4

class Tower_1_arrows_pos_2(pygame.sprite.Sprite):
    def __init__(self, tower_1_arrows_pos_2):
        super().__init__()

        self.image = tower_1_arrows_pos_2
        self.rect = self.image.get_rect(left=TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x += 3
        self.rect.y += 4

#  ********** Arrow 2 (blue)
tower_2_arrow_pos_1 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowdiag-0.png'))
tower_2_arrow_pos_2 = pygame.image.load(os.path.join('sprites', 'player2', 'bow', 'arrowdiag-0.png'))

class Arrow_2(pygame.sprite.Sprite):
    def __init__(self, arrow_2):
        super().__init__()

        self.image = arrow_2
        self.rect = self.image.get_rect(right=WIDTH - 685, top = GROUND_HEIGHT - (BOWMAN_HEIGHT/2) - 3)          # 685: average between the position in which the bowman can start shooting. 3: extra height of the arrow from the ground
    def update(self):
        self.rect.x -= ARROW_VEL


class Tower_2_arrow_pos_1(pygame.sprite.Sprite):
    def __init__(self, tower_2_arrow_pos_1):
        super().__init__()

        self.image = tower_2_arrow_pos_1
        self.rect = self.image.get_rect(left=WIDTH - TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x -= 6
        self.rect.y += 4

class Tower_2_arrow_pos_2(pygame.sprite.Sprite):
    def __init__(self, tower_2_arrow_pos_2):
        super().__init__()

        self.image = tower_2_arrow_pos_2
        self.rect = self.image.get_rect(left=WIDTH - TOWER_POS, top=HEIGHT - TOWER_HEIGHT)

    def update(self):
        # move diagonally
        self.rect.x -= 3
        self.rect.y += 4


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# ********** Tower 1 (red)
Redtower = []
Redtower.append(pygame.transform.scale(pygame.image.load('sprites/player1/building/tower2.png'), (TOWER_WIDTH, TOWER_HEIGHT)))

class Tower_1_red(pygame.sprite.Sprite):
    def __init__(self, Redtower):
        super(Tower_1_red, self).__init__()

        self.index = 0
        self.image = Redtower[self.index]

        self.rect = self.image.get_rect(right=TOWER_POS, bottom=GROUND_HEIGHT)

        self.image = Redtower[self.index]


# ********** Tower 2 (blue)
Bluetower = []
Bluetower.append(pygame.transform.scale(pygame.image.load('sprites/player2/building/tower2.png'), (TOWER_WIDTH, TOWER_HEIGHT)))

class Tower_2_blue(pygame.sprite.Sprite):
    def __init__(self, Bluetower):
        super(Tower_2_blue, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Bluetower[self.index]

        self.rect = self.image.get_rect(right=WIDTH - TOWER_POS + self.image.get_width(), bottom=GROUND_HEIGHT)

        self.image = Bluetower[self.index]


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# ********** Mine 1 (red)
Redmines = []
Redmines.append(pygame.transform.scale(pygame.image.load('sprites/player1/building/mine.png'), (MINE_WIDTH, MINE_HEIGHT)))

class Mine_1_red(pygame.sprite.Sprite):
    def __init__(self, Redmines):
        super(Mine_1_red, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Redmines[self.index]

        self.rect = self.image.get_rect(left=0, bottom=GROUND_HEIGHT)

    def update(self):
        self.tic += 1
        if self.tic == 11:
            self.index += 1
            self.tic = 0

        if self.index >= len(Redmines):
            self.index = 0

        self.image = Redmines[self.index]

# ********** Mine 2 (blue)
Bluemines = []
Bluemines.append(pygame.transform.scale(pygame.image.load('sprites/player2/building/mine.png'), (MINE_WIDTH, MINE_HEIGHT)))

class Mine_2_blue(pygame.sprite.Sprite):
    def __init__(self, Bluemines):
        super(Mine_2_blue, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Bluemines[self.index]

        self.rect = self.image.get_rect(right=WIDTH, bottom=GROUND_HEIGHT)

    def update(self):
        self.tic += 1
        if self.tic == 9:
            self.index += 1
            self.tic = 0

        if self.index >= len(Bluemines):
            self.index = 0

        self.image = Bluemines[self.index]


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** ANIMALS

# ********** Pig facing left
Pigleft = []
Pigleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig1.png"), (55/2,30/2)))
Pigleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig2.png"), (55/2,30/2)))
Pigleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig3.png"), (55/2,30/2)))
Pigleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig4.png"), (55/2,30/2)))

class Pig_facing_left(pygame.sprite.Sprite):
    def __init__(self, Pigleft):
        super(Pig_facing_left, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Pigleft[self.index]

        self.rect = self.image.get_rect(left = WIDTH - 275, bottom = GROUND_HEIGHT + 40)        # 275 and 50 were chosen on random (represent where the pig is located)

    def update(self):
        self.tic += 1
        if self.tic == 15:
            self.index += 1
            self.tic = 0

        if self.index >= len(Pigleft):
            self.index = 0

        self.image = Pigleft[self.index]


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# ********** Pig facing right
Pigright = []       # the images were loaded in a different ordered to make the two pig eat at different moment
Pigright.append(pygame.transform.flip(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig4.png"), (55/2,30/2)), True, False))
Pigright.append(pygame.transform.flip(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig3.png"), (55/2,30/2)), True, False))
Pigright.append(pygame.transform.flip(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig2.png"), (55/2,30/2)), True, False))
Pigright.append(pygame.transform.flip(pygame.transform.scale(pygame.image.load("ExtraAnimation/Pig/Pig1.png"), (55/2,30/2)), True, False))

class Pig_facing_right(pygame.sprite.Sprite):
    def __init__(self, Pigright):
        super(Pig_facing_right, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Pigright[self.index]

        self.rect = self.image.get_rect(left =421, bottom = GROUND_HEIGHT + 25)        # 421 and 25 were chosen on random (represent where the pig is located)

    def update(self):
        self.tic += 1
        if self.tic == 17:
            self.index += 1
            self.tic = 0

        if self.index >= len(Pigright):
            self.index = 0

        self.image = Pigright[self.index]


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# ********** Cow facing left
Cowleft = []
Cowleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Cow/Cow1.png"), (71/2,44/2)))
Cowleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Cow/Cow2.png"), (71/2,44/2)))
Cowleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Cow/Cow3.png"), (71/2,44/2)))
Cowleft.append(pygame.transform.scale(pygame.image.load("ExtraAnimation/Cow/Cow4.png"), (71/2,44/2)))

class Cow_facing_left(pygame.sprite.Sprite):
    def __init__(self, Cowleft):
        super(Cow_facing_left, self).__init__()

        self.index = 0
        self.tic = 0
        self.image = Cowleft[self.index]

        self.rect = self.image.get_rect(left = 123, bottom = GROUND_HEIGHT + 45)        # 123 and 45 were chosen on random (represent where the pig is located)

    def update(self):
        self.tic += 1
        if self.tic == 15:
            self.index += 1
            self.tic = 0

        if self.index >= len(Cowleft):
            self.index = 0

        self.image = Cowleft[self.index]

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** MANAGEMENT
def manage_swordmans(Swordman_1_list, Swordman_2_list, Tower_1_red_list, Tower_2_blue_list):

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # collision between swordsman

    for swordman in Swordman_2_list:
        if pygame.sprite.spritecollideany(swordman, Swordman_1_list):
            swordman.is_attack_units = True

        elif pygame.sprite.spritecollideany(swordman, Tower_1_red_list):
            swordman.is_attack_tower = True

        else:
            swordman.is_attack_units = False


    for swordman in Swordman_1_list:
        if pygame.sprite.spritecollideany(swordman, Swordman_2_list):
            swordman.is_attack_units = True

        elif pygame.sprite.spritecollideany(swordman, Tower_2_blue_list):
            swordman.is_attack_tower = True

        else:
            swordman.is_attack_units = False


    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # swordsman taking damage
    damage_constant = 7

    for swordman in Swordman_2_list:
        if swordman.is_attack_units == True:
            for swordman in Swordman_1_list:
                if swordman.is_attack_units == True:
                    swordman.health -= SWORDMAN_HIT / damage_constant         # in this way the fight last a little bit longer


    for swordman in Swordman_1_list:
        if swordman.is_attack_units == True:
            for swordman in Swordman_2_list:
                if swordman.is_attack_units == True:
                    swordman.health -= SWORDMAN_HIT / damage_constant         # in this way the fight last a little bit longer

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
def manage_workers(Worker_1_list, Worker_2_list, Mine_1_red_list, Mine_2_blue_list, Tower_1_red_list, Tower_2_blue_list, Pig_facing_left_list, Pig_facing_right_list):
    global total_worker_mine_1
    global total_worker_wall_1
    global total_worker_mine_2
    global total_worker_wall_2

    total_worker_mine_1 = 0
    total_worker_wall_1 = 0
    total_worker_mine_2 = 0
    total_worker_wall_2 = 0

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # collision between worker and mine and/or tower

    # check if worker1 reach the mine
    for worker in Worker_1_list:
        if pygame.sprite.spritecollideany(worker, Mine_1_red_list):
            worker.is_at_mine = True
            total_worker_mine_1 += 1

    # check if worker1 reach the wall
    for worker in Worker_1_list:
        if pygame.sprite.spritecollideany(worker, Tower_1_red_list):
            worker.is_at_wall = True
            total_worker_wall_1 += 1


    # check if worker2 reach the mine
    for worker in Worker_2_list:
        if pygame.sprite.spritecollideany(worker, Mine_2_blue_list):
            worker.is_at_mine = True
            total_worker_mine_2 += 1

    # check if worker1 reach the wall
    for worker in Worker_2_list:
        if pygame.sprite.spritecollideany(worker, Tower_2_blue_list):
            worker.is_at_wall = True
            total_worker_wall_2 += 1


# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
def manage_bowmans(Swordman_1_list, Swordman_2_list, Bowman_1_list, Bowman_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2):

    # check if bowman1 reach the shooting position
    for bowman in Bowman_1_list:
        if bowman.rect.x >= rd.randint(670, 700):  # when the bowman reach a position in a range it stops and start shooting. 670 and 700 chose by us
            bowman.isshoot = True

    # check if bowman2 reach the shooting position
    for bowman in Bowman_2_list:
        if bowman.rect.x <= rd.randint(WIDTH - 700, WIDTH - 670):   # when the bowman reach a position in a range it stops and start shooting. 670 and 700 chose by us
            bowman.isshoot = True

    # bowman1 collision with arrow, and health damage
    for bowman in Bowman_1_list:
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(bowman, Arrow_2_list):
                Arrow_2_list.remove(arrow)
                for bowman in Bowman_1_list:
                    if bowman.isshoot == True:
                        bowman.health -= BOWMAN_HIT

    # bowman2 collision with arrow, and health damage
    for bowman in Bowman_2_list:
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(bowman, Arrow_1_list):
                Arrow_1_list.remove(arrow)
                for bowman in Bowman_2_list:
                    if bowman.isshoot == True:
                        bowman.health -= BOWMAN_HIT

    # swordman collision with arrows, tower arrows and bowman
    for swordman in Swordman_1_list:
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(swordman, Arrow_2_list):
                Arrow_2_list.remove(arrow)
                swordman.health -= BOWMAN_HIT

        for arrow in Tower_2_arrow_list_pos_1:
            if pygame.sprite.spritecollideany(swordman, Tower_2_arrow_list_pos_1):
                Tower_2_arrow_list_pos_1.remove(arrow)
                swordman.health -= TOWER_HIT

        for arrow in Tower_2_arrow_list_pos_2:
            if pygame.sprite.spritecollideany(swordman, Tower_2_arrow_list_pos_2):
                Tower_2_arrow_list_pos_2.remove(arrow)
                swordman.health -= TOWER_HIT

        if pygame.sprite.spritecollideany(swordman, Bowman_2_list):
            swordman.is_attack_units = True
            if swordman.is_attack_units == True:
                for bowman in Bowman_2_list:
                    if bowman.isshoot == True:
                        bowman.health -= SWORDMAN_HIT / 10

    for swordman in Swordman_2_list:
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(swordman, Arrow_1_list):
                Arrow_1_list.remove(arrow)
                swordman.health -= BOWMAN_HIT

        for arrow in Tower_1_arrows_list_pos_1:
            if pygame.sprite.spritecollideany(swordman, Tower_1_arrows_list_pos_1):
                Tower_1_arrows_list_pos_1.remove(arrow)
                swordman.health -= TOWER_HIT

        for arrow in Tower_1_arrows_list_pos_2:
            if pygame.sprite.spritecollideany(swordman, Tower_1_arrows_list_pos_2):
                Tower_1_arrows_list_pos_2.remove(arrow)
                swordman.health -= TOWER_HIT

        if pygame.sprite.spritecollideany(swordman, Bowman_1_list):
            swordman.is_attack_units = True
            if swordman.is_attack_units == True:
                for bowman in Bowman_1_list:
                    if bowman.isshoot == True:
                        bowman.health -= SWORDMAN_HIT / 10

# \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
# RESUME GAME
def resume_game():
    play_again_text = font_number1.render(' -- press SPACE to resume --', True, "BLACK")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT // 2 - 160)

    # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    # SHOW SETTINGS TAB:

    # distance constants
    text_dis_x = 20
    text_dis_y = 40

    # *** filled rectangle
    des_rect_x = 500  # desired width of the rectangle
    des_rect_y = 425  # desired height of the rectangle
    top_left_rect_x = (WIDTH / 2) - (des_rect_x / 2)
    top_left_rect_y = (HEIGHT / 2) - (des_rect_y / 2)

    # by using this two lines we displayed the background and the bordered of the setting tab with the rounded corners
    pygame.draw.rect(DISPLAYSURF, GRAY, pygame.Rect(top_left_rect_x, top_left_rect_y, des_rect_x, des_rect_y), 1200, 40)  # 1200 chosen so that the rectangle is completed filled inside
    pygame.draw.rect(DISPLAYSURF, BLACK, pygame.Rect(top_left_rect_x, top_left_rect_y, des_rect_x, des_rect_y), 2, 40)  # 2 is the thickness of the border of the settings tab

    # *** filled circle top (old method)
    #radius = 30
    # top left circle
    #pygame.draw.circle(DISPLAYSURF, PURPLE, (top_left_rect_x, top_left_rect_y), radius)
    # top right circle
    #pygame.draw.circle(DISPLAYSURF, PURPLE, (top_left_rect_x + des_rect_x, top_left_rect_y), radius)
    # bottom left circle
    #pygame.draw.circle(DISPLAYSURF, PURPLE, (top_left_rect_x, top_left_rect_y + des_rect_y), radius)
    # bottom right circle
    #pygame.draw.circle(DISPLAYSURF, PURPLE, (top_left_rect_x + des_rect_x, top_left_rect_y + des_rect_y), radius)

    settings_text = font_number1.render('SETTINGS', True, "BLACK")
    settings_text_rect = settings_text.get_rect()
    settings_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (text_dis_y * 0.5))

    PL1_text = font_number1.render('-- PL1 --', True, "RED")
    PL1_text_rect = PL1_text.get_rect()
    PL1_text_rect.center = (top_left_rect_x + (2 * text_dis_x), top_left_rect_y + (2 * text_dis_y))

    PL2_text = font_number1.render('-- PL2 --', True, "BLUE")
    PL2_text_rect = PL2_text.get_rect()
    PL2_text_rect.center = (top_left_rect_x + des_rect_x - (2 * text_dis_x), top_left_rect_y + (2 * text_dis_y))

    generate_worker_text = font_number1.render('Generate worker', True, "BLACK")
    generate_worker_text_rect = generate_worker_text.get_rect()
    generate_worker_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (3 * text_dis_y))

    generate_swordman_text = font_number1.render('Generate swordsman', True, "BLACK")
    generate_swordman_text_rect = generate_swordman_text.get_rect()
    generate_swordman_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (4 * text_dis_y))

    generate_bowman_text = font_number1.render('Generate bowman', True, "BLACK")
    generate_bowman_text_rect = generate_bowman_text.get_rect()
    generate_bowman_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (5 * text_dis_y))

    unleash_worker_mine_text = font_number1.render('Unleash workers to mine', True, "BLACK")
    unleash_worker_mine_text_rect = unleash_worker_mine_text.get_rect()
    unleash_worker_mine_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (6 * text_dis_y))

    unleash_worker_wall_text = font_number1.render('Unleash workers to wall', True, "BLACK")
    unleash_worker_wall_text_rect = unleash_worker_wall_text.get_rect()
    unleash_worker_wall_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (7 * text_dis_y))

    unleash_swordman_text = font_number1.render('Unleash swordsman', True, "BLACK")
    unleash_swordman_text_rect = unleash_swordman_text.get_rect()
    unleash_swordman_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (8 * text_dis_y))

    unleash_bowman_text = font_number1.render('Unleash bowman', True, "BLACK")
    unleash_bowman_text_rect = unleash_bowman_text.get_rect()
    unleash_bowman_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (9 * text_dis_y))

    unleash_all_text = font_number1.render('Unleash all units', True, "BLACK")
    unleash_all_text_rect = unleash_all_text.get_rect()
    unleash_all_text_rect.center = (WIDTH / 2, HEIGHT / 2 - (des_rect_y / 2) + (10 * text_dis_y))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # PLAYER RED TEXT

    PL1_worker_text = font_number1.render('Q', True, "RED")
    PL1_worker_text_rect = PL1_worker_text.get_rect()
    PL1_worker_text_rect.center = (top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (3 * text_dis_y))

    PL1_swordman_text = font_number1.render('W', True, "RED")
    PL1_swordman_text_rect = PL1_swordman_text.get_rect()
    PL1_swordman_text_rect.center = (
    top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (4 * text_dis_y))

    PL1_bowman_text = font_number1.render('E', True, "RED")
    PL1_bowman_text_rect = PL1_bowman_text.get_rect()
    PL1_bowman_text_rect.center = (top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (5 * text_dis_y))

    PL1_worker_mine_text = font_number1.render('A', True, "RED")
    PL1_worker_mine_text_rect = PL1_worker_mine_text.get_rect()
    PL1_worker_mine_text_rect.center = (
    top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (6 * text_dis_y))

    PL1_worker_wall_text = font_number1.render('S', True, "RED")
    PL1_worker_wall_text_rect = PL1_worker_wall_text.get_rect()
    PL1_worker_wall_text_rect.center = (
    top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (7 * text_dis_y))

    PL1_unleash_swordman_text = font_number1.render('D', True, "RED")
    PL1_unleash_swordman_text_rect = PL1_unleash_swordman_text.get_rect()
    PL1_unleash_swordman_text_rect.center = (
    top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (8 * text_dis_y))

    PL1_unleash_bowman_text = font_number1.render('F', True, "RED")
    PL1_unleash_bowman_text_rect = PL1_unleash_bowman_text.get_rect()
    PL1_unleash_bowman_text_rect.center = (
    top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (9 * text_dis_y))

    PL1_all_text = font_number1.render('Z', True, "RED")
    PL1_all_text_rect = PL1_all_text.get_rect()
    PL1_all_text_rect.center = (top_left_rect_x + (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (10 * text_dis_y))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # PLAYER BLUE TEXT

    PL2_worker_text = font_number1.render('P', True, "BLUE")
    PL2_worker_text_rect = PL2_worker_text.get_rect()
    PL2_worker_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (3 * text_dis_y))

    PL2_swordman_text = font_number1.render('O', True, "BLUE")
    PL2_swordman_text_rect = PL2_swordman_text.get_rect()
    PL2_swordman_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (4 * text_dis_y))

    PL2_bowman_text = font_number1.render('I', True, "BLUE")
    PL2_bowman_text_rect = PL2_bowman_text.get_rect()
    PL2_bowman_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (5 * text_dis_y))

    PL2_worker_mine_text = font_number1.render('L', True, "BLUE")
    PL2_worker_mine_text_rect = PL2_worker_mine_text.get_rect()
    PL2_worker_mine_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (6 * text_dis_y))

    PL2_worker_wall_text = font_number1.render('K', True, "BLUE")
    PL2_worker_wall_text_rect = PL2_worker_wall_text.get_rect()
    PL2_worker_wall_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (7 * text_dis_y))

    PL2_unleash_swordman_text = font_number1.render('J', True, "BLUE")
    PL2_unleash_swordman_text_rect = PL2_unleash_swordman_text.get_rect()
    PL2_unleash_swordman_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (8 * text_dis_y))

    PL2_unleash_bowman_text = font_number1.render('H', True, "BLUE")
    PL2_unleash_bowman_text_rect = PL2_unleash_bowman_text.get_rect()
    PL2_unleash_bowman_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (9 * text_dis_y))

    PL2_all_text = font_number1.render('M', True, "BLUE")
    PL2_all_text_rect = PL2_all_text.get_rect()
    PL2_all_text_rect.center = (
    top_left_rect_x + des_rect_x - (2 * text_dis_x), HEIGHT / 2 - (des_rect_y / 2) + (10 * text_dis_y))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # display all the text in the setting tab
    DISPLAYSURF.blit(play_again_text, play_again_rect)
    DISPLAYSURF.blit(settings_text, settings_text_rect)
    DISPLAYSURF.blit(PL1_text, PL1_text_rect)
    DISPLAYSURF.blit(PL2_text, PL2_text_rect)
    DISPLAYSURF.blit(generate_worker_text, generate_worker_text_rect)
    DISPLAYSURF.blit(generate_swordman_text, generate_swordman_text_rect)
    DISPLAYSURF.blit(generate_bowman_text, generate_bowman_text_rect)
    DISPLAYSURF.blit(unleash_worker_mine_text, unleash_worker_mine_text_rect)
    DISPLAYSURF.blit(unleash_worker_wall_text, unleash_worker_wall_text_rect)
    DISPLAYSURF.blit(unleash_swordman_text, unleash_swordman_text_rect)
    DISPLAYSURF.blit(unleash_bowman_text, unleash_bowman_text_rect)
    DISPLAYSURF.blit(unleash_all_text, unleash_all_text_rect)

    # display the red player text (on the left)
    DISPLAYSURF.blit(PL1_worker_text, PL1_worker_text_rect)
    DISPLAYSURF.blit(PL1_swordman_text, PL1_swordman_text_rect)
    DISPLAYSURF.blit(PL1_bowman_text, PL1_bowman_text_rect)
    DISPLAYSURF.blit(PL1_worker_mine_text, PL1_worker_mine_text_rect)
    DISPLAYSURF.blit(PL1_worker_wall_text, PL1_worker_wall_text_rect)
    DISPLAYSURF.blit(PL1_unleash_swordman_text, PL1_unleash_swordman_text_rect)
    DISPLAYSURF.blit(PL1_unleash_bowman_text, PL1_unleash_bowman_text_rect)
    DISPLAYSURF.blit(PL1_all_text, PL1_all_text_rect)

    # display the blue player text (on the right)
    DISPLAYSURF.blit(PL2_worker_text, PL2_worker_text_rect)
    DISPLAYSURF.blit(PL2_swordman_text, PL2_swordman_text_rect)
    DISPLAYSURF.blit(PL2_bowman_text, PL2_bowman_text_rect)
    DISPLAYSURF.blit(PL2_worker_mine_text, PL2_worker_mine_text_rect)
    DISPLAYSURF.blit(PL2_worker_wall_text, PL2_worker_wall_text_rect)
    DISPLAYSURF.blit(PL2_unleash_swordman_text, PL2_unleash_swordman_text_rect)
    DISPLAYSURF.blit(PL2_unleash_bowman_text, PL2_unleash_bowman_text_rect)
    DISPLAYSURF.blit(PL2_all_text, PL2_all_text_rect)

    pygame.display.update()

    resume = False
    while not resume:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                resume = True

            if event.type == pygame.QUIT:
                pygame.quit()


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# DISPLAY SETTINGS:
def draw_text(GAME_START, game_stats, Swordman_1_list, Swordman_2_list, Worker_1_list, Worker_2_list, Bowman_1_list, Bowman_2_list, Pig_facing_left_list, Pig_facing_right_list):
    # variables used for displaying text:

    temp_y = 110                    # variable for better displaying the text position
    font_distance_x = 23            # variable for better displaying the text position
    font_distance_y = 23            # variable for better displaying the text position

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Player 1 units

    redinfo_text = font_number2.render("----- INFO -----", True, "RED")
    redinfo_text_rect = redinfo_text.get_rect()
    redinfo_text_rect.topleft = (font_distance_x, temp_y)

    red_swordman_text = font_number2.render("Swordman alive: " + str(len(Swordman_1_list)), True, "RED")
    red_swordman_text_rect = red_swordman_text.get_rect()
    red_swordman_text_rect.topleft = (font_distance_x, temp_y + (font_distance_y * 2))

    red_worker_text = font_number2.render("Workers alive: " + str(len(Worker_1_list)), True, "RED")
    red_worker_text_rect = red_worker_text.get_rect()
    red_worker_text_rect.topleft = (font_distance_x, temp_y + (font_distance_y * 1))

    red_bowman_text = font_number2.render("Bowman alive: " + str(len(Bowman_1_list)), True, "RED")
    red_bowman_text_rect = red_bowman_text.get_rect()
    red_bowman_text_rect.topleft = (font_distance_x, temp_y + (font_distance_y * 3))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Player 2 units

    blueinfo_text = font_number2.render("----- INFO -----", True, "BLUE")
    blueinfo_text_rect = blueinfo_text.get_rect()
    blueinfo_text_rect.topright = (WIDTH - font_distance_x, temp_y)

    blue_swordman_text = font_number2.render("Swordman alive: " + str(len(Swordman_2_list)), True, "BLUE")
    blue_swordman__text_rect = blue_swordman_text.get_rect()
    blue_swordman__text_rect.topright = (WIDTH - font_distance_x, temp_y + (2 * font_distance_y))

    blue_worker_text = font_number2.render("Worker alive: " + str(len(Worker_2_list)), True, "BLUE")
    blue_worker_text_rect = blue_worker_text.get_rect()
    blue_worker_text_rect.topright = (WIDTH - font_distance_x, temp_y + (1 * font_distance_y))

    blue_bowman_text = font_number2.render("Bowman alive: " + str(len(Bowman_2_list)), True, "BLUE")
    blue_bowman_text_rect = blue_bowman_text.get_rect()
    blue_bowman_text_rect.topright = (WIDTH - font_distance_x, temp_y + (3 * font_distance_y))

    # opening display
    play_text = font_number2.render("PRESS 'ENTER' TO PLAY", True, "WHITE")
    play_rect = play_text.get_rect()
    play_rect.center = (WIDTH // 2, HEIGHT // 2 + 35)

    title_text = font_number3.render("CASTLEWAR", True, "WHITE")
    title_rect = title_text.get_rect()
    title_rect.center = (WIDTH // 2, 30)

    # tower health and resources
    Tower_1_red_hp_text = font_number2.render(f'TOWER HEALTH: {game_stats["Tower_1_red_health"]}', True, RED)
    Tower_1_red_hp_rect = Tower_1_red_hp_text.get_rect()
    Tower_1_red_hp_rect.topleft = (len(str(Tower_1_red_hp_text)), 50)

    Tower_2_blue_hp_text = font_number2.render(f'TOWER HEALTH: {game_stats["Tower_2_blue_health"]}', True, BLUE)
    Tower_2_blue_hp_rect = Tower_2_blue_hp_text.get_rect()
    Tower_2_blue_hp_rect.topright = (WIDTH - len(str(Tower_2_blue_hp_text)), 50)

    resources_1_text = font_number2.render(f'RESOURCES: {game_stats["PL1_resources"]}', True, RED)
    resources_1_rect = resources_1_text.get_rect()
    resources_1_rect.topleft = (len(str(resources_1_text)), 70)

    resources_2_text = font_number2.render(f'RESOURCES: {game_stats["PL2_resources"]}', True, BLUE)
    resources_2_rect = resources_2_text.get_rect()
    resources_2_rect.topright = (WIDTH - len(str(resources_2_text)), 70)

    # the texts that have to appear only after the match starts are blit here
    if GAME_START == False:
        DISPLAYSURF.blit(title_text, title_rect)
        DISPLAYSURF.blit(play_text, play_rect)

    if GAME_START == True:
        DISPLAYSURF.blit(Tower_1_red_hp_text, Tower_1_red_hp_rect)
        DISPLAYSURF.blit(Tower_2_blue_hp_text, Tower_2_blue_hp_rect)
        DISPLAYSURF.blit(resources_1_text, resources_1_rect)
        DISPLAYSURF.blit(resources_2_text, resources_2_rect)

        DISPLAYSURF.blit(redinfo_text, redinfo_text_rect)
        DISPLAYSURF.blit(red_swordman_text, red_swordman_text_rect)
        DISPLAYSURF.blit(red_worker_text, red_worker_text_rect)
        DISPLAYSURF.blit(red_bowman_text, red_bowman_text_rect)
        DISPLAYSURF.blit(blueinfo_text, blueinfo_text_rect)
        DISPLAYSURF.blit(blue_swordman_text, blue_swordman__text_rect)
        DISPLAYSURF.blit(blue_worker_text, blue_worker_text_rect)
        DISPLAYSURF.blit(blue_bowman_text, blue_bowman_text_rect)

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# draw and update all the elements displayed
def draw_window(GAME_START, game_stats, Swordman_1_list, Swordman_2_list, Worker_1_list, Worker_2_list,
                Bowman_1_list, Bowman_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2,
                Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2, Tower_1_red_list, Tower_2_blue_list, Mine_1_red_list, Mine_2_blue_list, Pig_facing_left_list, Pig_facing_right_list, Cow_facing_left_list):

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Display the "buildings"
    DISPLAYSURF.fill(LIGHTBLUE)
    DISPLAYSURF.blit(background_image, (0, 0))

    Tower_1_red_list.draw(DISPLAYSURF)
    Tower_1_red_list.update()

    Tower_2_blue_list.draw(DISPLAYSURF)
    Tower_2_blue_list.update()

    DISPLAYSURF.blit(Redbarrack, (80, GROUND_HEIGHT - BARRACK_HEIGHT))
    DISPLAYSURF.blit(Bluebarrack, (WIDTH - 80 - Bluebarrack.get_width(), GROUND_HEIGHT - BARRACK_HEIGHT))

    Mine_1_red_list.draw(DISPLAYSURF)
    Mine_1_red_list.update()

    Mine_2_blue_list.draw(DISPLAYSURF)
    Mine_2_blue_list.update()

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # display the units
    Swordman_1_list.draw(DISPLAYSURF)
    Swordman_1_list.update()

    Swordman_2_list.draw(DISPLAYSURF)
    Swordman_2_list.update()

    Worker_1_list.draw(DISPLAYSURF)
    Worker_1_list.update()

    Worker_2_list.draw(DISPLAYSURF)
    Worker_2_list.update()

    Bowman_1_list.draw(DISPLAYSURF)
    Bowman_1_list.update()

    Bowman_2_list.draw(DISPLAYSURF)
    Bowman_2_list.update()

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Display the arrows
    Arrow_1_list.draw(DISPLAYSURF)
    Arrow_1_list.update()

    Arrow_2_list.draw(DISPLAYSURF)
    Arrow_2_list.update()

    Tower_1_arrows_list_pos_1.draw(DISPLAYSURF)
    Tower_1_arrows_list_pos_1.update()

    Tower_1_arrows_list_pos_2.draw(DISPLAYSURF)
    Tower_1_arrows_list_pos_2.update()

    Tower_2_arrow_list_pos_1.draw(DISPLAYSURF)
    Tower_2_arrow_list_pos_1.update()

    Tower_2_arrow_list_pos_2.draw(DISPLAYSURF)
    Tower_2_arrow_list_pos_2.update()

    pygame.draw.rect(DISPLAYSURF, RECT_COLOR, bottom_rect)  # bottom black ground

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Display the animals
    Pig_facing_left_list.draw(DISPLAYSURF)
    Pig_facing_left_list.update()

    Pig_facing_right_list.draw(DISPLAYSURF)
    Pig_facing_right_list.update()

    Cow_facing_left_list.draw(DISPLAYSURF)
    Cow_facing_left_list.update()

    draw_text(GAME_START, game_stats, Swordman_1_list, Swordman_2_list, Worker_1_list, Worker_2_list,
              Bowman_1_list, Bowman_2_list, Pig_facing_left_list, Pig_facing_right_list)

    pygame.display.update()

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# SAVE PROGRAM
saveloadmanager = SaveLoadSystem(".save", "save_data")

game_stats = saveloadmanager.load_game_data(["game_stats", "number"], [[], 1])
#game_stats = saveloadmanager.load_data("game_stats")

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# MAIN FUNCTION

def main():

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # variables
    GAME_START = False
    enemy_in_range_pos_1 = False        # first range of the tower
    enemy_in_range_pos_2 = False        # second range of the tower

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Display animals
    pig_left_image = Pig_facing_left(Pigleft)
    Pig_facing_left_list = pygame.sprite.Group(pig_left_image)

    pig_right_image = Pig_facing_right(Pigright)
    Pig_facing_right_list = pygame.sprite.Group(pig_right_image)

    cow_left_image = Cow_facing_left(Cowleft)
    Cow_facing_left_list = pygame.sprite.Group(cow_left_image)

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # Create sprite Groups
    Swordman_1_list = pygame.sprite.Group()
    Swordman_2_list = pygame.sprite.Group()

    Worker_1_list = pygame.sprite.Group()
    Worker_2_list = pygame.sprite.Group()

    Bowman_1_list = pygame.sprite.Group()
    Bowman_2_list = pygame.sprite.Group()

    Arrow_1_list = pygame.sprite.Group()
    Arrow_2_list = pygame.sprite.Group()

    Tower_1_arrows_list_pos_1 = pygame.sprite.Group()
    Tower_2_arrow_list_pos_1 = pygame.sprite.Group()

    Tower_1_arrows_list_pos_2 = pygame.sprite.Group()
    Tower_2_arrow_list_pos_2 = pygame.sprite.Group()

    red_tower = Tower_1_red(Redtower)
    red_mines = Mine_1_red(Redmines)
    Tower_1_red_list = pygame.sprite.Group(red_tower)
    Mine_1_red_list = pygame.sprite.Group(red_mines)

    blue_tower = Tower_2_blue(Bluetower)
    blue_mines = Mine_2_blue(Bluemines)
    Tower_2_blue_list = pygame.sprite.Group(blue_tower)
    Mine_2_blue_list = pygame.sprite.Group(blue_mines)

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    #  ********** Final counting
    global total_swordman_generated_1
    global total_bowman_generated_1
    global total_worker_generated_1
    global total_swordman_death_1
    global total_bowman_death_1
    global total_resources_1
    global total_resources_used_1

    global total_swordman_generated_2
    global total_bowman_generated_2
    global total_worker_generated_2
    global total_swordman_death_2
    global total_bowman_death_2
    global total_resources_2
    global total_resources_used_2

    # at the beginning set them to the initial value

    # player 1
    total_swordman_generated_1 = 0
    total_bowman_generated_1 = 0
    total_worker_generated_1 = 0
    total_swordman_death_1 = 0
    total_bowman_death_1 = 0
    total_resources_1 = INIT_RESOURCES1
    total_resources_used_1 = 0

    # player 2
    total_swordman_generated_2 = 0
    total_bowman_generated_2 = 0
    total_worker_generated_2 = 0
    total_swordman_death_2 = 0
    total_bowman_death_2 = 0
    total_resources_2 = INIT_RESOURCES2
    total_resources_used_2 = 0

    # counters
    counter_1 = 0
    counter_2 = 0
    Tower_1_redcount = 0
    Tower_2_bluecount = 0

    Arrow_1_counter = 0
    Arrow_2_counter = 0

    Tower_1_redhealth_count = 0
    Tower_2_bluehealth_count = 0

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # game_stats
    game_stats = {"PL1_resources": INIT_RESOURCES, "PL2_resources": INIT_RESOURCES, "Tower_1_red_health": TOWER_HEALTH,
            "Tower_2_blue_health": TOWER_HEALTH}

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    while True:

        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_RETURN and GAME_START == False:     # pressing return the game
                    pygame.mixer.music.play(-1)                         #for playing it in loop
                    GAME_START = True


                if event.key == pygame.K_SPACE and GAME_START == True:  # pressing space the game
                    pygame.mixer.music.pause()                          # pause music
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                        resume_game()
                        pygame.mixer.music.unpause()                   # start music again

                if event.key == pygame.K_v:
                   saveloadmanager.save_game_data([game_stats], ["game_stats"])

                if event.key == pygame.K_b:
                    pass

                if GAME_START == True:

                    # controls for each key and the units it dispatches

                    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/oo
                    # GENERATE THE UNITS

                    # Player 1 units
                    # generate swordman 1
                    if event.key == pygame.K_w and game_stats['PL1_resources'] >= SWORDMAN_COST:
                        red_swordman = Swordman_1(ready_1_swordman, run_1_swordman, attack_1_swordman, fallen_1_swordman)
                        Swordman_1_list.add(red_swordman)
                        game_stats['PL1_resources'] -= SWORDMAN_COST
                        total_swordman_generated_1 += 1
                        total_resources_used_1 += SWORDMAN_COST

                    # generate worker 1
                    if event.key == pygame.K_q and game_stats['PL1_resources'] >= WORKER_COST:
                        red_worker = Worker_1(worker_1_ready, run_1_workers_mine, run_1_workers_tower, mine_1_worker, repair_1_worker)
                        Worker_1_list.add(red_worker)
                        game_stats['PL1_resources'] -= WORKER_COST
                        total_worker_generated_1 += 1
                        total_resources_used_1 += WORKER_COST

                    # generate bowman 1
                    if event.key == pygame.K_e and game_stats['PL1_resources'] >= BOWMAN_COST:
                        red_bowman = Bowman_1(ready_1_bowman, run_1_bowman, shoot_1_bowman, fallen_1_bowman)
                        Bowman_1_list.add(red_bowman)
                        game_stats['PL1_resources'] -= BOWMAN_COST
                        total_bowman_generated_1 += 1
                        total_resources_used_1 += BOWMAN_COST

                    # unleash swordman 1
                    if event.key == pygame.K_d:
                        for swordman in Swordman_1_list:
                            swordman.unleash = True

                    # unleash worker to mine 1
                    if event.key == pygame.K_a:
                        for red_worker in Worker_1_list:
                            if red_worker.gototower == False:
                                red_worker.gotominer = True

                    # unleash worker to wall2
                    if event.key == pygame.K_s:
                        for red_worker in Worker_1_list:
                            if red_worker.gotominer == False:
                                red_worker.gototower = True

                    # unleash bowman 1
                    if event.key == pygame.K_f:
                        for bowman in Bowman_1_list:
                            bowman.unleash = True

                    # unleash all units 1
                    if event.key == pygame.K_z:
                        for red_swordman in Swordman_1_list:
                            red_swordman.unleash = True

                        for red_worker in Worker_1_list:
                            if red_worker.gotominer == False:
                                red_worker.gototower = True

                        for red_bowman in Bowman_1_list:
                            red_bowman.unleash = True

                        # this was used to test the ending part of the code
                    """if event.key == pygame.K_c:
                        finish_game_red()

                    if event.key == pygame.K_v:
                        finish_game_blue()"""

                    # Player 2 units
                    # generate swordman 2
                    if event.key == pygame.K_o and game_stats['PL2_resources'] >= SWORDMAN_COST:
                        blue_swordman = Swordman_2(ready_2_swordman, run_2_swordman, attack_2_swordman, fallen_2_swordman)
                        Swordman_2_list.add(blue_swordman)
                        game_stats['PL2_resources'] -= SWORDMAN_COST
                        total_swordman_generated_2 += 1
                        total_resources_used_2 += SWORDMAN_COST

                    # generate worker 2
                    if event.key == pygame.K_p and game_stats['PL2_resources'] >= WORKER_COST:  # blue workers
                        blue_worker = Worker_2(ready_2_worker, run_2_workers_mine, run_2_workers_tower, mine_2_worker,repair_2_worker)
                        Worker_2_list.add(blue_worker)
                        game_stats['PL2_resources'] -= WORKER_COST
                        total_worker_generated_2 += 1
                        total_resources_used_2 += WORKER_COST

                    # generate bowman 2
                    if event.key == pygame.K_i and game_stats['PL2_resources'] >= BOWMAN_COST:
                        blue_bowman = Bowman_2(ready_2_bowman, run_2_bowman, shoot_2_bowman)
                        Bowman_2_list.add(blue_bowman)
                        game_stats['PL2_resources'] -= BOWMAN_COST
                        total_bowman_generated_2 += 1
                        total_resources_used_2 += BOWMAN_COST

                    # unleash swordman 2
                    if event.key == pygame.K_j:
                        for swordman in Swordman_2_list:
                            swordman.unleash = True

                    # unleash worker to mine 2
                    if event.key == pygame.K_l:
                        for blue_worker in Worker_2_list:
                            if blue_worker.gototower == False:
                                blue_worker.gotominer = True

                    # unleash worker to wall 2
                    if event.key == pygame.K_k:
                        for blue_worker in Worker_2_list:
                            if blue_worker.gotominer == False:
                                blue_worker.gototower = True

                    # unleash bowman 2
                    if event.key == pygame.K_h:
                        for bowman in Bowman_2_list:
                            bowman.unleash = True

                    # unleash all units 2
                    if event.key == pygame.K_m:
                        for blue_swordman in Swordman_2_list:
                            blue_swordman.unleash = True

                        for blue_worker in Worker_2_list:
                            if blue_worker.gotominer == False:
                                blue_worker.gototower = True

                        for blue_bowman in Bowman_2_list:
                            blue_bowman.unleash = True

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # detect when to shoot an arrow

        for swordman in Swordman_2_list:
            # when a swordman 2 enter range 1
            if swordman.rect.x == TOWER_RANGE_1:
                enemy_in_range_pos_1 = True
                if enemy_in_range_pos_1 == True:
                    Tower_1_arrows_list_pos_1.add(Tower_1_arrows_pos_1(tower_1_arrows_pos_1))

            # when a swordman 2 enter range 2
            if swordman.rect.x == TOWER_RANGE_2:
                enemy_in_range_pos_2 = True
                if enemy_in_range_pos_2 == True:
                    Tower_1_arrows_list_pos_2.add(Tower_1_arrows_pos_2(tower_1_arrows_pos_2))

        for swordman in Swordman_1_list:
            # when a swordman 1 enter range 1
            if swordman.rect.x == WIDTH - TOWER_RANGE_1:
                enemy_in_range_pos_1 = True
                if enemy_in_range_pos_1 == True:
                    Tower_2_arrow_list_pos_1.add(Tower_2_arrow_pos_1(tower_2_arrow_pos_1))

            # when a swordman 1 enter range 2
            if swordman.rect.x == WIDTH - TOWER_RANGE_2:
                enemy_in_range_pos_2 = True
                if enemy_in_range_pos_2 == True:
                    Tower_2_arrow_list_pos_2.add(Tower_2_arrow_pos_2(tower_2_arrow_pos_2))

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # manage the swordmans hit to the enemy tower and its health
        for red_swordman in Swordman_1_list:
            if red_swordman.is_attack_tower == True:
                Tower_2_bluehealth_count += 1
                if Tower_2_bluehealth_count == 100:
                    Tower_2_bluehealth_count = 0
                    game_stats['Tower_2_blue_health'] -= SWORDMAN_HIT
                    # finish game
                    if game_stats['Tower_2_blue_health'] <= 0:
                        finish_game_red()

        for blue_swordman in Swordman_2_list:
            if blue_swordman.is_attack_tower == True:
                Tower_1_redhealth_count += 1
                if Tower_1_redhealth_count == 100:
                    Tower_1_redhealth_count = 0
                    game_stats['Tower_1_red_health'] -= SWORDMAN_HIT
                    if game_stats['Tower_1_red_health'] <= 0:
                        # finish game
                        finish_game_blue()

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # manage the amount of resources per worker and the reparation

        # player 1
        for red_worker in Worker_1_list:
            if red_worker.is_at_mine == True:
                counter_1 += 1
                if counter_1 == 100:
                    counter_1 = 0
                    game_stats['PL1_resources'] += WORKER_PROD
                    total_resources_1 += WORKER_PROD

            if red_worker.is_at_wall == True:
                Tower_1_redcount += 1
                if Tower_1_redcount == 100:
                    Tower_1_redcount = 0
                    game_stats['Tower_1_red_health'] += WORKER_REPAIR
                    if game_stats['Tower_1_red_health'] >= TOWER_HEALTH:
                        game_stats['Tower_1_red_health'] = TOWER_HEALTH

        # player 2
        for blue_worker in Worker_2_list:
            if blue_worker.is_at_mine == True:
                counter_2 += 1
                if counter_2 == 100:
                    counter_2 = 0
                    game_stats['PL2_resources'] += WORKER_PROD
                    total_resources_2 += WORKER_PROD

            if blue_worker.is_at_wall == True:
                Tower_2_bluecount += 1
                if Tower_2_bluecount == 100:
                    Tower_2_bluecount = 0
                    game_stats["Tower_2_blue_health"] += WORKER_REPAIR
                    if game_stats["Tower_2_blue_health"] >= TOWER_HEALTH:
                        game_stats["Tower_2_blue_health"] = TOWER_HEALTH

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # manage when to shoot an arrow (the loop is similar to the animation loop in the bowman class, to have animation and arrow shooting at the same time)

        # player 1
        for bowman in Bowman_1_list:
            if bowman.isshoot == True:
                Arrow_1_counter += 1
                if Arrow_1_counter == BOWMAN_REST:
                    Arrow_1_list.add(Arrow_1(arrow_1))
                if Arrow_1_counter == 230:
                    Arrow_1_counter = 0

        # player 2
        for bowman in Bowman_2_list:
            if bowman.isshoot == True:
                Arrow_2_counter += 1
                if Arrow_2_counter == BOWMAN_REST:
                    Arrow_2_list.add(Arrow_2(arrow_2))
                if Arrow_2_counter == 230:
                    Arrow_2_counter = 0

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # manage arrow hit to the enemy tower and its health

        # player 1
        for arrow in Arrow_1_list:
            if pygame.sprite.spritecollideany(arrow, Tower_2_blue_list):
                Arrow_1_list.remove(arrow)
                game_stats['Tower_2_blue_health'] -= BOWMAN_HIT
                if game_stats['Tower_2_blue_health'] <= 0:
                    finish_game_red()

        # player 2
        for arrow in Arrow_2_list:
            if pygame.sprite.spritecollideany(arrow, Tower_1_red_list):
                Arrow_2_list.remove(arrow)
                game_stats['Tower_1_red_health'] -= BOWMAN_HIT
                if game_stats['Tower_1_red_health'] <= 0:
                    finish_game_blue()

        # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        # manage and draw
        manage_swordmans(Swordman_1_list, Swordman_2_list, Tower_1_red_list, Tower_2_blue_list)
        manage_workers(Worker_1_list, Worker_2_list, Mine_1_red_list, Mine_2_blue_list, Tower_1_red_list, Tower_2_blue_list, Pig_facing_left_list, Pig_facing_right_list)
        manage_bowmans(Swordman_1_list, Swordman_2_list, Bowman_1_list, Bowman_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2)

        draw_window(GAME_START, game_stats, Swordman_1_list, Swordman_2_list, Worker_1_list, Worker_2_list, Bowman_1_list, Bowman_2_list, Arrow_1_list, Arrow_2_list, Tower_1_arrows_list_pos_1, Tower_1_arrows_list_pos_2, Tower_2_arrow_list_pos_1, Tower_2_arrow_list_pos_2, Tower_1_red_list, Tower_2_blue_list, Mine_1_red_list, Mine_2_blue_list, Pig_facing_left_list, Pig_facing_right_list, Cow_facing_left_list)

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# ****** END GAME
winning_font = pygame.font.SysFont("freesansbold.ttf", 50)  # for both red and blue

def finish_game_stats():

    #end music
    pygame.mixer.music.load('end-titles-edited1.mp3')
    pygame.mixer.music.play(-1)

    # constant to display the text in a better way (use for distances)
    cos_x = 20
    cos_y = 30

    des_rect_x = 275  # desired width of the rectangle
    des_rect_y = 400  # desired height of the rectangle

    # LEFT RECTANGLE (RED)
    top_left_rect_x_red = (WIDTH / 3) - (des_rect_x / 2)
    top_left_rect_y_red = (HEIGHT / 2) - (des_rect_y / 2)

    pygame.draw.rect(DISPLAYSURF, GRAY, pygame.Rect(top_left_rect_x_red, top_left_rect_y_red, des_rect_x, des_rect_y), 1200, 40)
    pygame.draw.rect(DISPLAYSURF, BLACK, pygame.Rect(top_left_rect_x_red, top_left_rect_y_red, des_rect_x, des_rect_y), 3, 40)

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # RED AVOID 0
    # avoid divide by 0 (case in which there are 0 swordman)
    try:
        percentage_total_swordman_1 = int((total_swordman_generated_1 * 100) / (total_swordman_generated_1 + total_bowman_generated_1 + total_worker_generated_1))
    except:
        percentage_total_swordman_1 = 0

    # avoid divide by 0 (case in which there are 0 bowman)
    try:
        percentage_total_bowman_1 = int((total_bowman_generated_1 * 100) / (total_swordman_generated_1 + total_bowman_generated_1 + total_worker_generated_1))
    except:
        percentage_total_bowman_1 = 0

    # avoid divide by 0 (case in which there are 0 worker)
    try:
        percentage_total_worker_1 = int((total_worker_generated_1 * 100) / ( total_swordman_generated_1 + total_bowman_generated_1 + total_worker_generated_1))
    except:
        percentage_total_worker_1 = 0

    # avoid divide by 0 (case in which there are 0 workers to mine)
    try:
        percentage_total_worker_mine_1 = int((total_worker_mine_1 * 100) / total_worker_generated_1)
    except:
        percentage_total_worker_mine_1 = 0

    # avoid divide by 0 (case in which there are 0 workers to wall)
    try:
        percentage_total_worker_wall_1 = int((total_worker_wall_1 * 100) / total_worker_generated_1)
    except:
        percentage_total_worker_wall_1 = 0

    # avoid divide by 0 (case in which there are 0 death swordman)
    try:
        percentage_total_swordman_death_1 = int((total_swordman_death_1 * 100)/(total_swordman_death_1 + total_bowman_death_1))
    except:
        percentage_total_swordman_death_1 = 0

    # avoid divide by 0 (case in which there are 0 death bowman)
    try:
        percentage_total_bowman_death_1 = int((total_bowman_death_1 * 100)/(total_swordman_death_1 + total_bowman_death_1))
    except:
        percentage_total_bowman_death_1 = 0

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # RED TEXT
    stats_1_text = font_number3.render(" --- RED STATS ---", True, "RED")
    stats_1_rect = stats_1_text.get_rect()
    stats_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (1 * cos_y))

    total_units_generated_1_text = font_number2.render("Total units generated: " + str(total_swordman_generated_1 + total_bowman_generated_1 + total_worker_generated_1), True, "BLACK")
    total_units_generated_1_rect = total_units_generated_1_text.get_rect()
    total_units_generated_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (2 * cos_y))

    total_swordman_generated_1_text = font_number2.render("Total swordsman generated: " + str(total_swordman_generated_1) + " (" + str(percentage_total_swordman_1) + "%)", True, "BLACK")
    total_swordman_generated_1_rect = total_swordman_generated_1_text.get_rect()
    total_swordman_generated_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (3 * cos_y))

    total_bowman_generated_1_text = font_number2.render("Total bowman generated: " + str(total_bowman_generated_1) + " (" + str(percentage_total_bowman_1) + "%)", True, "BLACK")
    total_bowman_generated_1_rect = total_bowman_generated_1_text.get_rect()
    total_bowman_generated_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (4 * cos_y))

    total_worker_generated_1_text = font_number2.render("Total workers generated: " + str(total_worker_generated_1) + " (" + str(percentage_total_worker_1) + "%)", True, "BLACK")
    total_worker_generated_1_rect = total_worker_generated_1_text.get_rect()
    total_worker_generated_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (5 * cos_y))

    total_units_death_1_text = font_number2.render("Total units death: " + str(total_swordman_death_1 + total_bowman_death_1), True, "BLACK")
    total_units_death_1_rect = total_units_death_1_text.get_rect()
    total_units_death_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (6 * cos_y))

    total_swordman_death_1_text = font_number2.render("Total swordsman death: " + str(total_swordman_death_1) + " (" + str(percentage_total_swordman_death_1) + "%)", True, "BLACK")
    total_swordman_death_1_rect = total_swordman_death_1_text.get_rect()
    total_swordman_death_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (7 * cos_y))

    total_bowman_death_1_text = font_number2.render("Total bowman death: " + str(total_bowman_death_1) + " (" + str(percentage_total_bowman_death_1) + "%)", True, "BLACK")
    total_bowman_death_1_rect = total_bowman_death_1_text.get_rect()
    total_bowman_death_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (8 * cos_y))

    total_worker_mine_1_text = font_number2.render("Total workers to mine: " + str(total_worker_mine_1) + " (" + str(percentage_total_worker_mine_1) + "%)", True, "BLACK")
    total_worker_mine_1_rect = total_worker_mine_1_text.get_rect()
    total_worker_mine_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (9 * cos_y))

    total_worker_wall_1_text = font_number2.render("Total workers to wall: " + str(total_worker_wall_1) + " (" + str(percentage_total_worker_wall_1) + "%)", True, "BLACK")
    total_worker_wall_1_rect = total_worker_wall_1_text.get_rect()
    total_worker_wall_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (10 * cos_y))

    total_resources_1_text = font_number2.render("Total resources: " + str(total_resources_1), True, "BLACK")
    total_resources_1_rect = total_resources_1_text.get_rect()
    total_resources_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (11 * cos_y))

    total_resources_used_1_text = font_number2.render("Total resources used: " + str(total_resources_used_1) + " (" + str(int((total_resources_used_1 * 100) / total_resources_1)) + "%)", True, "BLACK")
    total_resources_used_1_rect = total_resources_used_1_text.get_rect()
    total_resources_used_1_rect.center = (top_left_rect_x_red + (des_rect_x / 2), top_left_rect_y_red + (12 * cos_y))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # BLUE SECTION

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # RIGHT RECTANGLE (BLUE)
    top_left_rect_x_blue = (2 * WIDTH / 3) - (des_rect_x / 2)
    top_left_rect_y_blue = (HEIGHT / 2) - (des_rect_y / 2)

    pygame.draw.rect(DISPLAYSURF, GRAY, pygame.Rect(top_left_rect_x_blue, top_left_rect_y_blue, des_rect_x, des_rect_y), 1200, 40)
    pygame.draw.rect(DISPLAYSURF, BLACK, pygame.Rect(top_left_rect_x_blue, top_left_rect_y_blue, des_rect_x, des_rect_y), 3, 40)

    # BLUE AVOID 0
    # avoid divide by 0 (case in which there are 0 swordman)
    try:
        percentage_total_swordman_2 = int((total_swordman_generated_2 * 100) / (total_swordman_generated_2 + total_bowman_generated_2 + total_worker_generated_2))
    except:
        percentage_total_swordman_2 = 0

    # avoid divide by 0 (case in which there are 0 bowman)
    try:
        percentage_total_bowman_2 = int((total_bowman_generated_2 * 100) / (total_swordman_generated_2 + total_bowman_generated_2 + total_worker_generated_2))
    except:
        percentage_total_bowman_2 = 0

    # avoid divide by 0 (case in which there are 0 worker)
    try:
        percentage_total_worker_2 = int((total_worker_generated_2 * 100) / (total_swordman_generated_2 + total_bowman_generated_2 + total_worker_generated_2))
    except:
        percentage_total_worker_2 = 0

    # avoid divide by 0 (case in which there are 0 workers to mine)
    try:
        percentage_total_worker_mine_2 = int((total_worker_mine_2 * 100) / total_worker_generated_2)
    except:
        percentage_total_worker_mine_2 = 0

    # avoid divide by 0 (case in which there are 0 workers to wall)
    try:
        percentage_total_worker_wall_2 = int((total_worker_wall_2 * 100) / total_worker_generated_2)
    except:
        percentage_total_worker_wall_2 = 0

    # avoid divide by 0 (case in which there are 0 death swordman)
    try:
        percentage_total_swordman_death_2 = int((total_swordman_death_2 * 100) / (total_swordman_death_2 + total_bowman_death_2))
    except:
        percentage_total_swordman_death_2 = 0

    # avoid divide by 0 (case in which there are 0 death bowman)
    try:
        percentage_total_bowman_death_2 = int((total_bowman_death_2 * 100) / (total_swordman_death_2 + total_bowman_death_2))
    except:
        percentage_total_bowman_death_2 = 0

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # BLUE TEXT
    stats_2_text = font_number3.render(" --- BLUE STATS ---", True, "BLUE")
    stats_2_rect = stats_2_text.get_rect()
    stats_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (1 * cos_y))

    total_units_generated_2_text = font_number2.render("Total units generated: " + str( total_swordman_generated_2 + total_bowman_generated_2 + total_worker_generated_2), True, "BLACK")
    total_units_generated_2_rect = total_units_generated_2_text.get_rect()
    total_units_generated_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (2 * cos_y))

    total_swordman_generated_2_text = font_number2.render("Total swordsman generated: " + str(total_swordman_generated_2) + " (" + str(percentage_total_swordman_2) + "%)", True, "BLACK")
    total_swordman_generated_2_rect = total_swordman_generated_2_text.get_rect()
    total_swordman_generated_2_rect.center = (
    top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (3 * cos_y))

    total_bowman_generated_2_text = font_number2.render("Total bowman generated: " + str(total_bowman_generated_2) + " (" + str(percentage_total_bowman_2) + "%)", True, "BLACK")
    total_bowman_generated_2_rect = total_bowman_generated_2_text.get_rect()
    total_bowman_generated_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (4 * cos_y))

    total_worker_generated_2_text = font_number2.render("Total workers generated: " + str(total_worker_generated_2) + " (" + str(percentage_total_worker_2) + "%)", True,"BLACK")
    total_worker_generated_2_rect = total_worker_generated_2_text.get_rect()
    total_worker_generated_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (5 * cos_y))

    total_units_death_2_text = font_number2.render("Total units death: " + str(total_swordman_death_2 + total_bowman_death_2), True, "BLACK")
    total_units_death_2_rect = total_units_death_2_text.get_rect()
    total_units_death_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (6 * cos_y))

    total_swordman_death_2_text = font_number2.render("Total swordsman death: " + str(total_swordman_death_2) + " (" + str(percentage_total_swordman_death_2) + "%)", True, "BLACK")
    total_swordman_death_2_rect = total_swordman_death_2_text.get_rect()
    total_swordman_death_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (7 * cos_y))

    total_bowman_death_2_text = font_number2.render("Total bowman death: " + str(total_bowman_death_2) + " (" + str(percentage_total_bowman_death_2) + "%)", True, "BLACK")
    total_bowman_death_2_rect = total_bowman_death_2_text.get_rect()
    total_bowman_death_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (8 * cos_y))

    total_worker_mine_2_text = font_number2.render("Total workers to mine: " + str(total_worker_mine_2) + " (" + str(percentage_total_worker_mine_2) + "%)", True, "BLACK")
    total_worker_mine_2_rect = total_worker_mine_2_text.get_rect()
    total_worker_mine_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (9 * cos_y))

    total_worker_wall_2_text = font_number2.render("Total workers to wall: " + str(total_worker_wall_2) + " (" + str(percentage_total_worker_wall_2) + "%)", True, "BLACK")
    total_worker_wall_2_rect = total_worker_wall_2_text.get_rect()
    total_worker_wall_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (10 * cos_y))

    total_resources_2_text = font_number2.render("Total resources: " + str(total_resources_2), True, "BLACK")
    total_resources_2_rect = total_resources_2_text.get_rect()
    total_resources_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (11 * cos_y))

    total_resources_used_2_text = font_number2.render("Total resources used: " + str(total_resources_used_2) + " (" + str(int((total_resources_used_2 * 100) / total_resources_2)) + "%)", True, "BLACK")
    total_resources_used_2_rect = total_resources_used_2_text.get_rect()
    total_resources_used_2_rect.center = (top_left_rect_x_blue + (des_rect_x / 2), top_left_rect_y_blue + (12 * cos_y))

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # DISPLAY ALL

    DISPLAYSURF.blit(stats_1_text, stats_1_rect)
    DISPLAYSURF.blit(total_units_generated_1_text, total_units_generated_1_rect)
    DISPLAYSURF.blit(total_swordman_generated_1_text, total_swordman_generated_1_rect)
    DISPLAYSURF.blit(total_bowman_generated_1_text, total_bowman_generated_1_rect)
    DISPLAYSURF.blit(total_worker_generated_1_text, total_worker_generated_1_rect)
    DISPLAYSURF.blit(total_units_death_1_text, total_units_death_1_rect)
    DISPLAYSURF.blit(total_swordman_death_1_text, total_swordman_death_1_rect)
    DISPLAYSURF.blit(total_bowman_death_1_text, total_bowman_death_1_rect)
    DISPLAYSURF.blit(total_worker_mine_1_text, total_worker_mine_1_rect)
    DISPLAYSURF.blit(total_worker_wall_1_text, total_worker_wall_1_rect)
    DISPLAYSURF.blit(total_resources_1_text, total_resources_1_rect)
    DISPLAYSURF.blit(total_resources_used_1_text, total_resources_used_1_rect)

    DISPLAYSURF.blit(stats_2_text, stats_2_rect)
    DISPLAYSURF.blit(total_units_generated_2_text, total_units_generated_2_rect)
    DISPLAYSURF.blit(total_swordman_generated_2_text, total_swordman_generated_2_rect)
    DISPLAYSURF.blit(total_bowman_generated_2_text, total_bowman_generated_2_rect)
    DISPLAYSURF.blit(total_worker_generated_2_text, total_worker_generated_2_rect)
    DISPLAYSURF.blit(total_units_death_2_text, total_units_death_2_rect)
    DISPLAYSURF.blit(total_swordman_death_2_text, total_swordman_death_2_rect)
    DISPLAYSURF.blit(total_bowman_death_2_text, total_bowman_death_2_rect)
    DISPLAYSURF.blit(total_worker_mine_2_text, total_worker_mine_2_rect)
    DISPLAYSURF.blit(total_worker_wall_2_text, total_worker_wall_2_rect)
    DISPLAYSURF.blit(total_resources_2_text, total_resources_2_rect)
    DISPLAYSURF.blit(total_resources_used_2_text, total_resources_used_2_rect)


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# BLUE WIN
def finish_game_blue():

    # display stats
    finish_game_stats()
    pygame.mixer.music.stop()

    # music for the end game
    pygame.mixer.music.load('end-titles-edited1.mp3')
    pygame.mixer.music.play(-1)

    finish_game_text = winning_font.render('BLUE WON', True, BLUE)
    finish_game_rect = finish_game_text.get_rect()
    finish_game_rect.center = (WIDTH // 2, HEIGHT // 13)

    play_again_text = font_number1.render('press "enter" to play again', True, "BLACK")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT // 13 + 40)


    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # DISPLAY ALL
    DISPLAYSURF.blit(finish_game_text, finish_game_rect)
    DISPLAYSURF.blit(play_again_text, play_again_rect)

    pygame.display.update()

    play_again = False
    while not play_again:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:

                pygame.mixer.music.stop()  # stop the end game music
                pygame.mixer.music.load('dance-of-nordic-leaves-epic-folk-original-soundtrack.mp3')  # load the main music
                pygame.mixer.music.play(-1)

                main()  # Play again the game
            if event.type == pygame.QUIT:
                pygame.quit()  # Quit the game
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# RED WIN
def finish_game_red():

    # display stats
    finish_game_stats()

    #end game music
    pygame.mixer.music.stop()
    pygame.mixer.music.load('end-titles-edited1.mp3')
    pygame.mixer.music.play(-1)

    finish_game_text = winning_font.render('RED WON', True, RED)
    finish_game_rect = finish_game_text.get_rect()
    finish_game_rect.center = (WIDTH // 2, HEIGHT // 13)

    play_again_text = font_number1.render('press "enter" to play again', True, "BLACK")
    play_again_rect = play_again_text.get_rect()
    play_again_rect.center = (WIDTH // 2, HEIGHT // 13 + 40)

    # \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    # DISPLAY ALL
    DISPLAYSURF.blit(finish_game_text, finish_game_rect)
    DISPLAYSURF.blit(play_again_text, play_again_rect)

    pygame.display.update()

    play_again = False
    while not play_again:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:

                pygame.mixer.music.stop()  # stop the end game music
                pygame.mixer.music.load('dance-of-nordic-leaves-epic-folk-original-soundtrack.mp3')  # load the main music
                pygame.mixer.music.play(-1)

                main() # Play again the game

            if event.type == pygame.QUIT:
                pygame.quit()  # Quit the game

# RUN THE PROGRAM
if __name__ == '__main__':
    main()
